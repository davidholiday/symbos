=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
     P C W   R E L E A S E   3 . 1
      Author: Prodatron/SymbiosiS
---------------------------------------
This archive contains:
---------------------------------------
[SymbOS-PCW.DSK]
   SymbOS PCW Release 3.1
   + screen saver + extened desktop
   + widgets + OS info
   Type SYM to boot SymbOS from CP/M

[Symbos-PCW-System.DSK]
   All system applications including
   the control panel

[Symbos-PCW-Applications.DSK]
   Several standard applications
   (30.12.2021)

You will find most up-to-date and new
applications and games here:
http://www.symbos.de/apps.htm
---------------------------------------
   For more information please visit
         http://www.symbos.de
=======================================
