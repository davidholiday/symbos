=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
     M S X   R E L E A S E   3 . 1
      Author: Prodatron/SymbiosiS
---------------------------------------
This archive contains:
---------------------------------------
[SymbOS-MSX-Setup.DSK]
   SymbOS MSX Release 3.1 setup DSK

[SymbOS-MSX-Setup.ZIP]
   SymbOS MSX Release 3.1 setup (ZIP-
    version)
   SYMSETUP.COM setup utility
   SYMSETUP.DAT setup data file

[SymbOS-MSX-Prepared.ZIP]
   SymbOS MSX Release 3.1 prepared
    installation
   Please copy all files to a disc or a
   prefered sub directory, where SymbOS
   will boot from, run SYMSETUP.COM and
   choose option [1] to finish it
---------------------------------------
    For more information about this
        production please visit
  http://www.symbos.org/download.htm
=======================================

-------------------------------------------------------------------------------
!PLEASE READ!              HOW TO INSTALL SYMBOS MSX              !PLEASE READ!
-------------------------------------------------------------------------------
SymbOS has to be installed first before it can be started for the first time.
Please insert the disc with the setup utility or copy SYMSETUP.COM and
SYMSETUP.DAT to your harddisc. You can now execute SYMSETUP.COM in MSX-DOS 1 or
MSX-DOS 2.

Now press 1 for a new installation. You will have to specify the destination
disc drive and directory (if MSX-DOS 2), where SymbOS should be installed and
later booted from.

The setup utility will now copy all required files to the destination place.
When finished you need to answer some questions regarding the device, where you
installed SymbOS and so from which you will boot it. As SymbOS is not based on
MSX-BIOS and MSX-DOS it needs to know from which disc drive, IDE channel or SD
card slot it will boot and from which partition.

Please note, that some MSX FDISK software (e.g. Sunrise IDE) create partitions
in the contrary order. The first MSX partition (Drive A) may be the logical
partition 4, drive B may be 3 etc.

After the setup you can boot SymbOS immediately with typing...
SYM    - to start the standard MSX version
SYMG9K - to start the Graphics 9000 edition; this will only work on an MSX with
         the Graphics 9000 graphic card
Now you can copy additional applications into your SymbOS directory. Use the
control panel to create new start menu and desktop icon links and to add your
additional drives and partitions.
-------------------------------------------------------------------------------
