=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
         I C O N   &   F O N T
          C O L L E C T I O N
---------------------------------------
This archive contains:
---------------------------------------
[fonts\]
   several fonts for using as
   alternative SymbOS system fonts or
   as fonts in your own applications
[icons\]
   a collection of many 16 colour icons
   for using inside the extended
   desktop
---------------------------------------
    For more information about this
        production please visit
  http://www.symbos.org/download.htm
=======================================
