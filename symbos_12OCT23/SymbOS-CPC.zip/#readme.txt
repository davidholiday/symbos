=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
     C P C   R E L E A S E   3 . 1
      Author: Prodatron/SymbiosiS
---------------------------------------
This archive contains:
---------------------------------------
[SymbOS-CPC-BootFast.DSK]
   SymbOS CPC Release 3.1 disc version
   with fast boot loader
   + screen saver + extened desktop
   + widgets + OS info
   Type RUN"SYM to boot SymbOS

[SymbOS-CPC-BootRaw.DSK]
   SymbOS CPC Release 3.1 disc version
   with Amsdos raw loader
   + screen saver + extened desktop
   + widgets + OS info
   -> Use this for booting from mass
      storage devices (M4, SF3)
   Type RUN"SYM to boot SymbOS

[SymbOS-CPC-MassStorage.ZIP]
   Full SymbOS CPC Release 3.1
   installation for CPCs with
   SYMBiFACE 3 or M4Board and memory
   expansion.
   Copy the whole file and directory
   structure into the root of your USB
   memory stick/SD card and type
   RUN"SYM to boot SymbOS

[Sym-RomA.ROM]
[Sym-RomB.ROM]
[Sym-RomC.ROM]
[Sym-RomD.ROM]
   SymbOS CPC Release 3.1 rom version
   -> Use this, if you want to boot
      SymbOS very fast from your rom
      expansion; only Sym-RomA must be
      placed in the visible area 1-15
      or 1-7 (CPC464), all others can
      be placed behind this
      Type |SYM for booting.

[SymbOS-CPC-AppsStandard.DSK]
   Standard application package
   + control panel (30.12.2021).
---------------------------------------
    Please download all addtional
    applications, tools, daemons
          and games here:
     http://www.symbos.de/apps.htm
---------------------------------------
   For more information please visit
         http://www.symbos.de
=======================================
