=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
    M S X   M A S S   S T O R A G E
      D E V I C E   D R I V E R S
      Author: Prodatron/SymbiosiS
---------------------------------------
This archive contains:
---------------------------------------
-fdmicso.drv - Microsol FDC driver
-fdnatio.drv - National FDC driver
               (MB8877A)
-fdpanas.drv - Toshiba FDC driver
               (Panasonic)
-fdphili.drv - Philips/Sony FDC driver
               (WD2793)
-fdsvi.drv   - SVI FDC driver
               (WD1793)
-idsunri.drv - Sunrise IDE driver
-sdmeda.drv  - MegaSD driver
-sdgr8n.drv  - Gr8Net SD card driver
[_Sources]
   Source codes of all included
   drivers.
---------------------------------------
    For more information about this
        production please visit
  http://www.symbos.org/download.htm
=======================================
