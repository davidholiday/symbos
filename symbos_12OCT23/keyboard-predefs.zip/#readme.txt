=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
            K E Y B O A R D
      P R E D E F I N I T I O N S
---------------------------------------
This archive contains:
---------------------------------------
cpc-uk.kyb   - British CPC keyboard
cpc-fr.kyb   - French CPC keyboard
cpc-es.kyb   - Spanish CPC keyboard
cpc-dk.kyb   - Danish CPC keyboard
msx-en.kyb   - English MSX keyboard
msx-jp.kyb   - Japanese MSX keyboard

**watch out for  more predefs soon or**
**support us with your contributions!**
---------------------------------------
    For more information about this
        production please visit
  http://www.symbos.org/download.htm
=======================================
