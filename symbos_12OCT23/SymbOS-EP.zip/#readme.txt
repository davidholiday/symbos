=======================================
*     ___       ____  _    ___  ___   *
*    /__  /__/ / / / /_\  /  / /__    *
*   ___/ ___/ /   / /__/ /__/ ___/    *
*       SYMBIOSIS MULTITASKING        *
*       BASED OPERATING SYSTEM        *
=======================================
      E P   R E L E A S E   3 . 1
      Author: Prodatron/SymbiosiS
---------------------------------------
This archive contains:
---------------------------------------
[SymbOS-EP.DSK]
   SymbOS EP Release 3.1 DSK
[SymbOS-EP.ZIP]
   SymbOS EP Release 3.1 as ZIP
[SymbOS-EP-SDCard.ZIP]
   SymbOS EP Release 3.1 SD Card Dump
   (copy to root of first partition F)

Type
RUN"SYM"
    to start the standard version
RUN"SYMG9K"
    to start the Graphics9000 version,
    which requires a V9990 graphic card
---------------------------------------
    For more information about this
        production please visit
  http://www.symbos.org/download.htm
=======================================
